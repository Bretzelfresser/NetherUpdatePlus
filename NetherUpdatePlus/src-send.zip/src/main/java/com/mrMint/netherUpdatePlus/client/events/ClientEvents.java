package com.mrMint.netherUpdatePlus.client.events;

import com.mrMint.netherUpdatePlus.NetherUpdatePlus;

import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(modid = NetherUpdatePlus.MODID, bus = Bus.FORGE)
public class ClientEvents {

}
